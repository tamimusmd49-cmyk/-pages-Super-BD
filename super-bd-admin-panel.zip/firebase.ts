import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

// Configuration provided by user
const firebaseConfig = {
  apiKey: "AIzaSyAj9ucI09arQLkJvKlJ8EEhzF538HhlHos",
  authDomain: "super-bd-9e1c1.firebaseapp.com",
  databaseURL: "https://super-bd-9e1c1-default-rtdb.firebaseio.com",
  projectId: "super-bd-9e1c1",
  storageBucket: "super-bd-9e1c1.firebasestorage.app",
  messagingSenderId: "220216131110",
  appId: "1:220216131110:web:1898c4e792fde5c78070e7",
  measurementId: "G-Q83JSQPR15"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);