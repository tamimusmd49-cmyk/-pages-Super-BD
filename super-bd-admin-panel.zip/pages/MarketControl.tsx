import React, { useEffect, useState } from 'react';
import { Activity, Save, TrendingUp, TrendingDown, Zap, RefreshCw, Minus, Plus } from 'lucide-react';
import { doc, setDoc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { MarketMode, MarketSettings } from '../types';

const MarketControl: React.FC = () => {
  const [settings, setSettings] = useState<MarketSettings>({
    basePrice: 120.00,
    mode: 'NORMAL',
  });
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'settings', 'market'), (doc) => {
      if (doc.exists()) {
        setSettings(doc.data() as MarketSettings);
      }
    });
    return () => unsub();
  }, []);

  const handleUpdate = async (newSettings?: Partial<MarketSettings>) => {
    setLoading(true);
    setSuccessMsg('');
    const updatedSettings = { ...settings, ...newSettings, lastUpdated: new Date() };
    
    // Optimistic update for UI
    if (newSettings) setSettings(updatedSettings);

    try {
      await setDoc(doc(db, 'settings', 'market'), updatedSettings);
      setSuccessMsg('Market updated!');
      setTimeout(() => setSuccessMsg(''), 2000);
    } catch (error) {
      console.error("Error updating market:", error);
      alert("Failed to update market settings.");
    } finally {
      setLoading(false);
    }
  };

  const adjustPrice = (amount: number) => {
    const newPrice = Number((settings.basePrice + amount).toFixed(2));
    handleUpdate({ basePrice: newPrice });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      
      {/* Header Section */}
      <div className="flex justify-between items-end border-b border-slate-200 pb-6">
        <div>
           <h2 className="text-3xl font-bold text-slate-800 flex items-center gap-2">
             <Activity className="text-blue-600" />
             Live Market Controller
           </h2>
           <p className="text-slate-500 mt-1">Real-time control center for user app charts</p>
        </div>
        {successMsg && (
          <div className="bg-green-100 text-green-700 px-4 py-2 rounded-full text-sm font-bold animate-fade-in flex items-center gap-2">
            <RefreshCw size={14} className="animate-spin" />
            {successMsg}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left: Main Price Controller */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Large Price Display */}
          <div className="bg-slate-900 text-white rounded-2xl p-8 shadow-xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500 rounded-full blur-[100px] opacity-20 -mr-16 -mt-16 transition-opacity group-hover:opacity-30"></div>
            
            <div className="relative z-10 flex justify-between items-center">
              <div>
                <p className="text-slate-400 font-medium mb-1 tracking-wider uppercase text-sm">Base Market Rate</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-bold text-slate-500">৳</span>
                  <span className="text-7xl font-black tracking-tight">{settings.basePrice.toFixed(2)}</span>
                </div>
              </div>
              <div className={`px-4 py-2 rounded-xl text-center backdrop-blur-md bg-white/10 border border-white/10`}>
                 <p className="text-xs text-slate-400 uppercase mb-1">Current Mode</p>
                 <p className={`text-lg font-bold ${
                   settings.mode === 'HIGH' ? 'text-green-400' : 
                   settings.mode === 'DOWN' ? 'text-red-400' : 'text-blue-400'
                 }`}>
                   {settings.mode}
                 </p>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="mt-8 pt-6 border-t border-white/10">
              <p className="text-xs text-slate-500 mb-3 uppercase font-semibold">Quick Price Adjust</p>
              <div className="flex gap-3 overflow-x-auto pb-2">
                <button onClick={() => adjustPrice(-5)} className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-300 rounded-lg font-mono font-bold transition-colors border border-red-500/20">- 5.00</button>
                <button onClick={() => adjustPrice(-1)} className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-300 rounded-lg font-mono font-bold transition-colors border border-red-500/20">- 1.00</button>
                <div className="w-px bg-white/10 mx-2"></div>
                <button onClick={() => adjustPrice(1)} className="px-4 py-2 bg-green-500/20 hover:bg-green-500/30 text-green-300 rounded-lg font-mono font-bold transition-colors border border-green-500/20">+ 1.00</button>
                <button onClick={() => adjustPrice(5)} className="px-4 py-2 bg-green-500/20 hover:bg-green-500/30 text-green-300 rounded-lg font-mono font-bold transition-colors border border-green-500/20">+ 5.00</button>
              </div>
            </div>
          </div>

          {/* Manual Input Card */}
          <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
             <label className="block text-sm font-bold text-slate-700 mb-3">Manual Price Entry</label>
             <div className="flex gap-4">
               <div className="relative flex-1">
                 <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">৳</span>
                 <input 
                   type="number" 
                   value={settings.basePrice}
                   onChange={(e) => setSettings({...settings, basePrice: parseFloat(e.target.value)})}
                   className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-300 rounded-xl font-bold text-lg focus:ring-2 focus:ring-blue-500 outline-none"
                 />
               </div>
               <button 
                onClick={() => handleUpdate()}
                disabled={loading}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-blue-200 transition-all flex items-center gap-2"
               >
                 <Save size={20} />
                 Set Price
               </button>
             </div>
          </div>
        </div>

        {/* Right: Mode Selector */}
        <div className="space-y-4">
          <h3 className="text-lg font-bold text-slate-700">Market Behavior Mode</h3>
          
          <button
            onClick={() => handleUpdate({ mode: 'NORMAL' })}
            className={`w-full text-left p-5 rounded-xl border-2 transition-all relative overflow-hidden group ${
              settings.mode === 'NORMAL' 
              ? 'border-blue-500 bg-blue-50' 
              : 'border-slate-200 bg-white hover:border-blue-300'
            }`}
          >
            <div className="relative z-10 flex items-start justify-between">
              <div>
                <span className={`block font-black text-lg ${settings.mode === 'NORMAL' ? 'text-blue-700' : 'text-slate-700'}`}>NORMAL</span>
                <span className="text-sm text-slate-500 mt-1 block">Fluctuates ±2.00 (Stable)</span>
              </div>
              <div className={`p-2 rounded-lg ${settings.mode === 'NORMAL' ? 'bg-blue-200 text-blue-700' : 'bg-slate-100 text-slate-400'}`}>
                <Activity size={24} />
              </div>
            </div>
            {settings.mode === 'NORMAL' && <div className="absolute bottom-0 left-0 w-full h-1 bg-blue-500"></div>}
          </button>

          <button
            onClick={() => handleUpdate({ mode: 'HIGH' })}
            className={`w-full text-left p-5 rounded-xl border-2 transition-all relative overflow-hidden group ${
              settings.mode === 'HIGH' 
              ? 'border-green-500 bg-green-50' 
              : 'border-slate-200 bg-white hover:border-green-300'
            }`}
          >
            <div className="relative z-10 flex items-start justify-between">
              <div>
                <span className={`block font-black text-lg ${settings.mode === 'HIGH' ? 'text-green-700' : 'text-slate-700'}`}>HIGH (PUMP)</span>
                <span className="text-sm text-slate-500 mt-1 block">Jumps rapidly to 160+</span>
              </div>
              <div className={`p-2 rounded-lg ${settings.mode === 'HIGH' ? 'bg-green-200 text-green-700' : 'bg-slate-100 text-slate-400'}`}>
                <TrendingUp size={24} />
              </div>
            </div>
            {settings.mode === 'HIGH' && <div className="absolute bottom-0 left-0 w-full h-1 bg-green-500"></div>}
          </button>

          <button
            onClick={() => handleUpdate({ mode: 'DOWN' })}
            className={`w-full text-left p-5 rounded-xl border-2 transition-all relative overflow-hidden group ${
              settings.mode === 'DOWN' 
              ? 'border-red-500 bg-red-50' 
              : 'border-slate-200 bg-white hover:border-red-300'
            }`}
          >
            <div className="relative z-10 flex items-start justify-between">
              <div>
                <span className={`block font-black text-lg ${settings.mode === 'DOWN' ? 'text-red-700' : 'text-slate-700'}`}>DOWN (CRASH)</span>
                <span className="text-sm text-slate-500 mt-1 block">Drops rapidly to 80+</span>
              </div>
              <div className={`p-2 rounded-lg ${settings.mode === 'DOWN' ? 'bg-red-200 text-red-700' : 'bg-slate-100 text-slate-400'}`}>
                <TrendingDown size={24} />
              </div>
            </div>
            {settings.mode === 'DOWN' && <div className="absolute bottom-0 left-0 w-full h-1 bg-red-500"></div>}
          </button>

        </div>
      </div>
    </div>
  );
};

export default MarketControl;