import React, { useState, useEffect } from 'react';
import { Check, X, RotateCcw } from 'lucide-react';
import { collection, query, where, onSnapshot, doc, runTransaction } from 'firebase/firestore';
import { db } from '../firebase';
import { Transaction } from '../types';

const DepositsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'pending' | 'history'>('pending');
  const [deposits, setDeposits] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    // We only query by 'type' to avoid "Composite Index" errors in Firestore.
    // Filtering by status is done in client-side for robustness.
    const q = query(
      collection(db, 'transactions'),
      where('type', '==', 'deposit')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const allDeposits = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction));
      
      // Client-side filtering
      const filteredData = allDeposits.filter(t => {
        if (activeTab === 'pending') return t.status === 'pending';
        return ['approved', 'rejected'].includes(t.status);
      });

      // Safe sorting by createdAt
      filteredData.sort((a, b) => {
        const timeA = a.createdAt?.seconds || 0;
        const timeB = b.createdAt?.seconds || 0;
        return timeB - timeA;
      });

      setDeposits(filteredData);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching deposits:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [activeTab]);

  const handleApprove = async (transaction: Transaction) => {
    if (!window.confirm(`Confirm Success? This will add ৳${transaction.amountBDT} (Approx $${transaction.amount}) to user balance.`)) return;

    try {
      await runTransaction(db, async (transactionDb) => {
        const userRef = doc(db, 'users', transaction.userId);
        const trxRef = doc(db, 'transactions', transaction.id);

        const userDoc = await transactionDb.get(userRef);
        if (!userDoc.exists()) throw new Error("User does not exist!");

        const newBalance = (userDoc.data().balance || 0) + transaction.amount;

        transactionDb.update(userRef, { balance: newBalance });
        transactionDb.update(trxRef, { status: 'approved' });
      });
      // onSnapshot will auto-update the UI
      alert("Success! Deposit approved and balance added.");
    } catch (error) {
      console.error("Approval failed", error);
      alert("Failed to approve transaction.");
    }
  };

  const handleReject = async (transactionId: string) => {
    if (!window.confirm("Reject this deposit request?")) return;
    try {
      await runTransaction(db, async (transactionDb) => {
         const trxRef = doc(db, 'transactions', transactionId);
         transactionDb.update(trxRef, { status: 'rejected' });
      });
    } catch (error) {
       alert("Failed to reject transaction.");
    }
  };

  const handleReset = async (transaction: Transaction) => {
    if (!window.confirm("Reset this transaction to Pending? If it was approved, balance will be deducted.")) return;

    try {
      await runTransaction(db, async (transactionDb) => {
        const trxRef = doc(db, 'transactions', transaction.id);
        const userRef = doc(db, 'users', transaction.userId);
        
        if (transaction.status === 'approved') {
          const userDoc = await transactionDb.get(userRef);
          if (userDoc.exists()) {
            const currentBal = userDoc.data().balance || 0;
            transactionDb.update(userRef, { balance: currentBal - transaction.amount });
          }
        }

        transactionDb.update(trxRef, { status: 'pending' });
      });
      alert("Transaction reset to Pending.");
    } catch (error) {
      console.error("Reset failed", error);
      alert("Failed to reset transaction.");
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-bold text-slate-800">Deposit Requests</h2>
        <div className="bg-white p-1 rounded-lg border border-slate-200 flex w-full sm:w-auto">
          <button 
            onClick={() => setActiveTab('pending')}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'pending' ? 'bg-blue-100 text-blue-700' : 'text-slate-500 hover:text-slate-700'}`}
          >
            Pending
          </button>
          <button 
            onClick={() => setActiveTab('history')}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'history' ? 'bg-slate-100 text-slate-700' : 'text-slate-500 hover:text-slate-700'}`}
          >
            History
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[600px]">
            <thead className="bg-slate-50">
              <tr>
                <th className="p-4 text-sm font-semibold text-slate-600">User Details</th>
                <th className="p-4 text-sm font-semibold text-slate-600">Method & TrxID</th>
                <th className="p-4 text-sm font-semibold text-slate-600">Amount</th>
                <th className="p-4 text-sm font-semibold text-slate-600">Status</th>
                <th className="p-4 text-sm font-semibold text-slate-600 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
               {loading ? (
                <tr><td colSpan={5} className="p-8 text-center text-slate-500">Loading requests...</td></tr>
              ) : deposits.length === 0 ? (
                 <tr><td colSpan={5} className="p-8 text-center text-slate-500">No {activeTab} deposits found.</td></tr>
              ) : (
                deposits.map(deposit => (
                  <tr key={deposit.id} className="hover:bg-slate-50 transition-colors">
                    <td className="p-4">
                      <div className="font-medium text-slate-800">{deposit.userName}</div>
                      <div className="text-sm text-slate-500">{deposit.userPhone}</div>
                    </td>
                    <td className="p-4">
                      <span className="px-2 py-0.5 rounded text-xs font-bold bg-purple-100 text-purple-700 mb-1 inline-block">{deposit.paymentMethod}</span>
                      <div className="text-sm font-mono text-slate-600">{deposit.trxId}</div>
                    </td>
                    <td className="p-4">
                      <div className="font-bold text-slate-800">৳{deposit.amountBDT}</div>
                      <div className="text-xs text-slate-500">${deposit.amount} USD</div>
                    </td>
                    <td className="p-4">
                       <span className={`px-2 py-1 rounded text-xs font-bold ${
                          deposit.status === 'approved' ? 'bg-green-100 text-green-700' : 
                          deposit.status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'
                        }`}>
                          {deposit.status.toUpperCase()}
                        </span>
                    </td>
                    <td className="p-4 text-right">
                      {activeTab === 'pending' ? (
                        <div className="flex justify-end space-x-2">
                          <button 
                            onClick={() => handleApprove(deposit)}
                            className="flex items-center space-x-1 bg-green-500 text-white px-3 py-2 rounded-lg hover:bg-green-600 transition-colors shadow-sm"
                          >
                            <Check size={16} />
                            <span className="hidden sm:inline">Success</span>
                          </button>
                          <button 
                            onClick={() => handleReject(deposit.id)}
                            className="flex items-center space-x-1 bg-red-50 text-red-600 px-3 py-2 rounded-lg hover:bg-red-100 transition-colors border border-red-100"
                          >
                            <X size={16} />
                            <span className="hidden sm:inline">Reject</span>
                          </button>
                        </div>
                      ) : (
                        <div className="flex justify-end">
                           <button 
                            onClick={() => handleReset(deposit)}
                            className="flex items-center space-x-1 bg-slate-100 text-slate-600 px-3 py-2 rounded-lg hover:bg-slate-200 transition-colors text-sm border border-slate-200"
                            title="Reset to Pending"
                          >
                            <RotateCcw size={16} />
                            <span className="hidden sm:inline">Reset</span>
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default DepositsPage;