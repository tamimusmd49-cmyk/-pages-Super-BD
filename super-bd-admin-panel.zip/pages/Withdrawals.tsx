import React, { useState, useEffect } from 'react';
import { Check, X, RotateCcw } from 'lucide-react';
import { collection, query, where, onSnapshot, doc, runTransaction } from 'firebase/firestore';
import { db } from '../firebase';
import { Transaction } from '../types';

const WithdrawalsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'pending' | 'history'>('pending');
  const [withdrawals, setWithdrawals] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    // Query only by 'type' to prevent index errors
    const q = query(
      collection(db, 'transactions'),
      where('type', '==', 'withdraw')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const allWithdrawals = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction));
      
      // Client-side filtering
      const filteredData = allWithdrawals.filter(t => {
        if (activeTab === 'pending') return t.status === 'pending';
        return ['paid', 'rejected'].includes(t.status);
      });

      // Safe sorting
      filteredData.sort((a, b) => {
        const timeA = a.createdAt?.seconds || 0;
        const timeB = b.createdAt?.seconds || 0;
        return timeB - timeA;
      });

      setWithdrawals(filteredData);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching withdrawals:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [activeTab]);

  const handleMarkPaid = async (transaction: Transaction) => {
    if (!window.confirm(`Confirm Success? This will deduct $${transaction.amount} from user balance (if not already held).`)) return;

    try {
      await runTransaction(db, async (transactionDb) => {
        const userRef = doc(db, 'users', transaction.userId);
        const trxRef = doc(db, 'transactions', transaction.id);
        
        const userDoc = await transactionDb.get(userRef);
        if (!userDoc.exists()) throw new Error("User missing");

        const currentBal = userDoc.data().balance || 0;
        if (currentBal < transaction.amount) {
            throw new Error("Insufficient user balance!");
        }

        transactionDb.update(userRef, { balance: currentBal - transaction.amount });
        transactionDb.update(trxRef, { status: 'paid' });
      });
      alert("Success! Withdrawal Paid and balance deducted.");
    } catch (error: any) {
      alert(`Failed: ${error.message}`);
    }
  };

  const handleReject = async (transactionId: string) => {
    if (!window.confirm("Reject withdrawal?")) return;
    try {
        await runTransaction(db, async (transactionDb) => {
            const trxRef = doc(db, 'transactions', transactionId);
            transactionDb.update(trxRef, { status: 'rejected' });
        });
    } catch (e) {
        alert("Error rejecting");
    }
  };

  const handleReset = async (transaction: Transaction) => {
    if (!window.confirm("Reset this transaction to Pending? If it was paid, balance will be refunded.")) return;

    try {
      await runTransaction(db, async (transactionDb) => {
        const trxRef = doc(db, 'transactions', transaction.id);
        const userRef = doc(db, 'users', transaction.userId);
        
        if (transaction.status === 'paid') {
          const userDoc = await transactionDb.get(userRef);
          if (userDoc.exists()) {
            const currentBal = userDoc.data().balance || 0;
            transactionDb.update(userRef, { balance: currentBal + transaction.amount });
          }
        }

        transactionDb.update(trxRef, { status: 'pending' });
      });
      alert("Transaction reset to Pending.");
    } catch (error) {
      console.error("Reset failed", error);
      alert("Failed to reset transaction.");
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-bold text-slate-800">Withdrawal Requests</h2>
        <div className="bg-white p-1 rounded-lg border border-slate-200 flex w-full sm:w-auto">
          <button 
            onClick={() => setActiveTab('pending')}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'pending' ? 'bg-orange-100 text-orange-700' : 'text-slate-500 hover:text-slate-700'}`}
          >
            Pending
          </button>
          <button 
            onClick={() => setActiveTab('history')}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'history' ? 'bg-slate-100 text-slate-700' : 'text-slate-500 hover:text-slate-700'}`}
          >
            History
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[600px]">
            <thead className="bg-slate-50">
              <tr>
                <th className="p-4 text-sm font-semibold text-slate-600">User</th>
                <th className="p-4 text-sm font-semibold text-slate-600">Target Info</th>
                <th className="p-4 text-sm font-semibold text-slate-600">Amount (USD)</th>
                <th className="p-4 text-sm font-semibold text-slate-600">Status</th>
                <th className="p-4 text-sm font-semibold text-slate-600 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
               {loading ? (
                <tr><td colSpan={5} className="p-8 text-center text-slate-500">Loading...</td></tr>
              ) : withdrawals.length === 0 ? (
                 <tr><td colSpan={5} className="p-8 text-center text-slate-500">No requests.</td></tr>
              ) : (
                withdrawals.map(wd => (
                  <tr key={wd.id} className="hover:bg-slate-50">
                    <td className="p-4 font-medium">{wd.userName}</td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                          <span className="text-xs font-bold bg-gray-200 px-2 py-1 rounded">{wd.paymentMethod}</span>
                          <span className="text-slate-600 font-mono">{wd.targetNumber}</span>
                      </div>
                    </td>
                    <td className="p-4 font-bold text-orange-600">${wd.amount}</td>
                    <td className="p-4">
                        <span className={`px-2 py-1 rounded text-xs font-bold ${
                              wd.status === 'paid' ? 'bg-green-100 text-green-700' : 
                              wd.status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-orange-100 text-orange-700'
                            }`}>
                              {wd.status.toUpperCase()}
                        </span>
                    </td>
                    <td className="p-4 text-right">
                      {activeTab === 'pending' ? (
                         <div className="flex justify-end space-x-2">
                         <button 
                           onClick={() => handleMarkPaid(wd)}
                           className="flex items-center space-x-1 bg-green-500 text-white px-3 py-2 rounded-lg hover:bg-green-600 text-sm shadow-sm"
                         >
                           <Check size={16} />
                           <span className="hidden sm:inline">Success</span>
                         </button>
                         <button 
                           onClick={() => handleReject(wd.id)}
                           className="flex items-center space-x-1 bg-red-50 text-red-600 px-3 py-2 rounded-lg hover:bg-red-100 text-sm border border-red-100"
                         >
                           <X size={16} />
                           <span className="hidden sm:inline">Reject</span>
                         </button>
                       </div>
                      ) : (
                         <div className="flex justify-end">
                            <button 
                             onClick={() => handleReset(wd)}
                             className="flex items-center space-x-1 bg-slate-100 text-slate-600 px-3 py-2 rounded-lg hover:bg-slate-200 transition-colors text-sm border border-slate-200"
                             title="Reset to Pending"
                           >
                             <RotateCcw size={16} />
                             <span className="hidden sm:inline">Reset</span>
                           </button>
                         </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default WithdrawalsPage;