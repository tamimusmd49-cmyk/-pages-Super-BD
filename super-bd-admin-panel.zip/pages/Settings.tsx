import React, { useState, useEffect } from 'react';
import { Save, Bell, Smartphone, Shield, Copy, Check } from 'lucide-react';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { AppSettings } from '../types';

const SettingsPage: React.FC = () => {
  const [settings, setSettings] = useState<AppSettings>({
    bkashNumber: '',
    nagadNumber: '',
    notices: ''
  });
  const [loading, setLoading] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const docRef = doc(db, 'settings', 'general');
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setSettings(docSnap.data() as AppSettings);
        }
      } catch (error) {
        console.error("Error fetching settings:", error);
      }
    };
    fetchSettings();
  }, []);

  const handleSave = async () => {
    setLoading(true);
    try {
      await setDoc(doc(db, 'settings', 'general'), settings);
      alert("Settings saved successfully!");
    } catch (error) {
      console.error("Error saving settings:", error);
      alert("Failed to save settings. Check permissions.");
    } finally {
      setLoading(false);
    }
  };

  const firestoreRules = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // === COMPREHENSIVE ADMIN RULES ===
    
    // 1. Settings (Market & App Config)
    match /settings/{document=**} {
      allow read, write: if true;
    }

    // 2. Users (Management & Balance)
    match /users/{userId} {
      allow read, write: if true;
    }

    // 3. Transactions (Deposits & Withdrawals)
    match /transactions/{transactionId} {
      allow read, write: if true;
    }

    // 4. Fallback for everything else
    match /{document=**} {
      allow read, write: if true;
    }
  }
}`;

  const handleCopyRules = () => {
    navigator.clipboard.writeText(firestoreRules);
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 2000);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold text-slate-800">General Settings</h2>
      
      <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-200 space-y-8">
        
        {/* Security Rules Section */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2 text-slate-800 border-b pb-2">
            <Shield size={20} className="text-blue-600" />
            <h3 className="font-semibold text-blue-600">Full Access Rules (Detailed)</h3>
          </div>
          <p className="text-sm text-slate-600">
            If the panel is not connecting, copy this detailed rule set. It explicitly allows access to Users, Transactions, and Settings collections.
          </p>
          <div className="bg-slate-900 rounded-lg p-4 relative group">
            <pre className="text-blue-400 font-mono text-xs md:text-sm overflow-x-auto whitespace-pre-wrap">
              {firestoreRules}
            </pre>
            <button 
              onClick={handleCopyRules}
              className="absolute top-2 right-2 p-2 bg-white/10 hover:bg-white/20 rounded text-white transition-colors flex items-center gap-2"
              title="Copy Rules"
            >
              {copySuccess ? (
                <>
                  <Check size={14} className="text-green-400" />
                  <span className="text-xs font-bold text-green-400">Copied</span>
                </>
              ) : (
                <>
                  <Copy size={14} />
                  <span className="text-xs">Copy</span>
                </>
              )}
            </button>
          </div>
          <p className="text-xs text-red-500 font-semibold mt-2">
            Important: Go to Firebase Console &gt; Firestore Database &gt; Rules, paste this, and click "Publish".
          </p>
        </div>

        {/* Payment Numbers */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2 text-slate-800 border-b pb-2">
            <Smartphone size={20} />
            <h3 className="font-semibold">Payment Numbers</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Bkash Personal/Agent</label>
              <input 
                type="text" 
                value={settings.bkashNumber}
                onChange={(e) => setSettings({...settings, bkashNumber: e.target.value})}
                placeholder="017..."
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Nagad Personal/Agent</label>
              <input 
                type="text" 
                value={settings.nagadNumber}
                onChange={(e) => setSettings({...settings, nagadNumber: e.target.value})}
                placeholder="016..."
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Notices */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2 text-slate-800 border-b pb-2">
            <Bell size={20} />
            <h3 className="font-semibold">App Notices</h3>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-600 mb-1">Scrolling Text / Popup Banner</label>
            <textarea 
              rows={4}
              value={settings.notices}
              onChange={(e) => setSettings({...settings, notices: e.target.value})}
              placeholder="Enter important announcement for users..."
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
            ></textarea>
          </div>
        </div>

        <div className="pt-4">
          <button 
            onClick={handleSave}
            disabled={loading}
            className="w-full bg-slate-800 hover:bg-slate-900 text-white py-3 rounded-lg font-medium flex items-center justify-center space-x-2 transition-colors"
          >
            <Save size={18} />
            <span>{loading ? 'Saving...' : 'Save Changes'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};

export default SettingsPage;