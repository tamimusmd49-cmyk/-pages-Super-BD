export interface User {
  id: string;
  name: string;
  phone: string;
  email?: string;
  balance: number;
  status: 'active' | 'banned';
  createdAt?: any;
}

export interface Transaction {
  id: string;
  userId: string;
  userName: string;
  userPhone: string;
  type: 'deposit' | 'withdraw';
  amount: number; // In USD or Unit
  amountBDT?: number;
  paymentMethod: 'Bkash' | 'Nagad' | 'Roket' | 'Other';
  trxId?: string; // For deposits
  targetNumber?: string; // For withdrawals
  status: 'pending' | 'approved' | 'rejected' | 'paid';
  createdAt: any; // Firestore Timestamp
}

export type MarketMode = 'NORMAL' | 'HIGH' | 'DOWN';

export interface MarketSettings {
  basePrice: number;
  mode: MarketMode;
  lastUpdated?: any;
}

export interface AppSettings {
  bkashNumber: string;
  nagadNumber: string;
  notices: string;
}