import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import UsersPage from './pages/Users';
import DepositsPage from './pages/Deposits';
import WithdrawalsPage from './pages/Withdrawals';
import { Menu } from 'lucide-react';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // No loading state or user check needed anymore.
  // Direct access granted.

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard />;
      case 'users': return <UsersPage />;
      case 'deposits': return <DepositsPage />;
      case 'withdrawals': return <WithdrawalsPage />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Mobile Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden"
          onClick={() => setIsSidebarOpen(false)}
        ></div>
      )}

      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={(tab) => {
          setActiveTab(tab);
          setIsSidebarOpen(false); // Close sidebar on mobile when item clicked
        }} 
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />
      
      <div className="flex-1 md:ml-64 flex flex-col h-screen overflow-hidden">
        <header className="bg-white shadow-sm sticky top-0 z-30 px-4 md:px-8 py-4 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 -ml-2 text-slate-600 hover:bg-slate-100 rounded-lg md:hidden"
            >
              <Menu size={24} />
            </button>
            <h2 className="text-xl font-semibold text-slate-800 capitalize truncate">
              {activeTab.replace('-', ' ')}
            </h2>
          </div>
          
          <div className="flex items-center space-x-4">
             <div className="text-right hidden sm:block">
                <p className="text-sm font-semibold text-slate-800">Administrator</p>
                <div className="flex items-center justify-end space-x-1">
                  <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
                  <p className="text-xs text-blue-600 font-medium">Auto-Logged In</p>
                </div>
             </div>
             <div className="w-10 h-10 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold border border-slate-200 shadow-sm shrink-0">
               A
             </div>
          </div>
        </header>

        <main className="p-4 md:p-8 overflow-y-auto flex-1 bg-slate-50">
          <div className="max-w-7xl mx-auto pb-20 md:pb-0">
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;